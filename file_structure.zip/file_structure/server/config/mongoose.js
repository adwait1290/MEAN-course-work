var mongoose = require('mongoose');

console.log('future mongoose connection and model loading');

mongose.connect('mongodb://localhost/first_mean');
